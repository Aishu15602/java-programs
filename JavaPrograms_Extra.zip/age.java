import java.util.Scanner;
public class age {
    public static void main(String []args){
        Scanner input = new Scanner(System.in);
        int age = input.nextInt();
        if (age>=1 && age<=10){
            System.out.println("Child");
        } else if (age>=11 && age<=18){
            System.out.println("Teenagers");
        } else if(age>=19 && age<=25){
            System.out.println("Youngsters");
        } else if(age>=26 && age<=50){
            System.out.println("Middle Agers");
        } else {
            System.out.println("Old Agers");
        }
    }
}