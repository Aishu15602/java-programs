import java.util.Scanner;
public class atm {
    public static void main(String []args){
        Scanner input = new Scanner(System.in);
        int num = input.nextInt();
        switch(num){
            case 1:
                System.out.println("Balance Check");
                break;
            case 2:
                System.out.println("Deposit");
                break;
            case 3:
                System.out.println("Withdrawal");
                break;
            case 4:
                System.out.println("Thank you bye bye!");
                break;
            default:
                System.out.println("Enter 1 to 3 for banking or 4 for exits");
        }
    }
}