import java.util.Scanner;
public class leapyear {
    public static void main(String []args){
        Scanner input = new Scanner(System.in);
        int num = input.nextInt();
        if((num%100==0 && num%400==0)||(num%100!=0 && num%4==0)){
            System.out.println("The year is leap year");
        } else {
            System.out.println("The year is not a leap year");
        }
    }
}