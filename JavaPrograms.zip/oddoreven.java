public class oddoreven{
    public static void main(String[]args){
        int num = 14;
        if (num % 2 == 0){
            System.out.println("The Number Is Even");
        } else {
            System.out.println("The Number Is Odd");
        }
    }
}